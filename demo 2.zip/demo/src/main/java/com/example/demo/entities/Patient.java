package com.example.demo.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@Setter
@Entity
public class Patient {
    @Id
    @GeneratedValue
    private Integer paitentId;
    private String name;
    private String address;
    private String mobileNo;
    private Integer age;

}
