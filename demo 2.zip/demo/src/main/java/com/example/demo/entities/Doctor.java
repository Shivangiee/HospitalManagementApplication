package com.example.demo.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.*;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Getter
@Setter
public class Doctor {
    @Id
    @GeneratedValue
    @Column(insertable=false, updatable=false)
    private Integer docId;
    private String name;
    private Long id;
    private String specialization;
    public String degree;
    public int experience ;
}
