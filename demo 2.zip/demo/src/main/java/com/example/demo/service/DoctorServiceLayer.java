package com.example.demo.service;

import com.example.demo.entities.Doctor;
import com.example.demo.repository.DoctorRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class DoctorServiceLayer {

    @Autowired
    private DoctorRepository doctorRepository;

    public Mono<Doctor> addDoctor(Doctor doctor) {
        return doctorRepository.save(doctor); // Saves doctor
    }

    public Flux<Doctor> getAllDoctors(String degree) {
        return doctorRepository.findAll() .filter(doctor -> doctor.getDegree().equals(degree));// Retrieves all doctors
    }






}
