package com.example.demo.service;

import com.example.demo.entities.Patient;
import com.example.demo.repository.DoctorRepository;
import com.example.demo.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
@Service
public class PatientServiceLayer {

    @Autowired
    private PatientRepository patientRepository;

    public Mono<Patient>addPatient(Patient patient){
        return patientRepository.save(patient);
    }
    public Mono<Patient> getPatientInfo(Integer patientId) {
        return patientRepository.findById(Long.valueOf(patientId)); // Assuming patientRepository has a findById method
    }
    public Mono<String> validateAge(int age) {
        return Mono.just(age)
                .filter(x -> x >= 18) // Filter for age >= 18
                .map(a -> "Age is " + a + " and is safe to give the dose") // Map to success message
                .onErrorReturn("Patient is below 18yrs"); // Return error message on filtering failure (age < 18)
    }


}
