package com.example.demo.controller;

import com.example.demo.entities.Doctor;
import com.example.demo.service.DoctorServiceLayer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
@Controller
@RequestMapping("/doctor")
public class DoctorController {
    @Autowired
    private DoctorServiceLayer doctorService;

    @PostMapping("/add")
    Mono<ResponseEntity<String>>addDoctor(@RequestBody Doctor doctor) {
        return doctorService.addDoctor(doctor)
                .map(savedDoctor -> new ResponseEntity<>("Doctor added with ID: " + savedDoctor.getDocId(), HttpStatus.CREATED));
    }
    @GetMapping("/all")
    public Flux<Doctor> getAllDoctors(@RequestParam  String degree) {
        return doctorService.getAllDoctors(degree);
    }


}
