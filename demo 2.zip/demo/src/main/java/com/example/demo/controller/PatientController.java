package com.example.demo.controller;

import com.example.demo.entities.Patient;
import com.example.demo.service.PatientServiceLayer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
@Controller
@RequestMapping("/patient")
public class PatientController {
    @Autowired
    private PatientServiceLayer patientService;

    @PostMapping("/add")
    Mono<ResponseEntity<Patient>> addPatient(@RequestBody Patient patient) {
        return patientService.addPatient(patient)
                .map(result -> new ResponseEntity<>(result, HttpStatus.CREATED));
    }
    @GetMapping("/getInfo")
    public Mono<Patient> getPatientInfo(@RequestParam Integer patientId) {
        return patientService.getPatientInfo(patientId);
    }
    @GetMapping("/validateAge")
    public Mono<String> validateAgeForDose(@RequestParam("age") Integer age) {
        return patientService.validateAge(age)
                .onErrorReturn("Invalid age provided"); // Handle errors more gracefully
    }



}
