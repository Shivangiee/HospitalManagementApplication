package com.example.demo.repository;

import com.example.demo.entities.Doctor;
import com.example.demo.entities.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface PatientRepository extends ReactiveCrudRepository<Patient,Long> {
    Mono<Integer> addPaitentToDb(Patient patient);
}
